Hello!

How to create a bot?

1. We find the contact @BotFather in Telegram.
2. Send him /newbot.
3. Choose a name for the bot.
4. Select the nickname of the bot (must end with Bot).
5. Copy the token.

1. Import the library.
(pip install pyTelegramBotAPI)
https://github.com/eternnoir/pyTelegramBotAPI

2. Put the token we got earlier into a variable.
3. Create a bot variable. It will be the key to the entire program. This is an object.
Inside it there are already functions that we will call.
4. A special syntax that specifies which messages the function defined next will process.
5. Definition of the echo function, which takes one parameter - the message (to which we will respond).
6. Function body. We send a message to the same chat from where we received it (message.chat.id)
with the same text (message.text).

