import telebot
import random

token = " "

bot = telebot.TeleBot(token)

RANDOM_TASKS = ["Call mom", "Do homework", "To wash a car"]

HELP = """
/help - display a list of available programs.
/add - add a task to the list (we ask the user for the task name)
/show - print all added tasks.
/random - add a random task for a date."""

tasks = {}

def add_todo(date, task):
    if date in tasks:
        # The date is in the dictionary
        # Adding a task to the list
        tasks[date].append(task)
    else:
        # No date in dictionary
        # Create an entry with the date key
        tasks[date] = [task]
        tasks[date].append(task)


@bot.message_handler(commands=["help"])
def help(message):
    bot.send_message(message.chat.id, HELP)

@bot.message_handler(commands=["add", "todo"])
def add(message):
    command = message.text.split(maxsplit=2)
    date = command[1].lower()
    task = command[2]
    add_todo(date, task[2])
    text = "Task " + task + " added on date " + date
    bot.send_message(message.chat.id, text)

@bot.message_handler(commands=["random"])
def random_add(message):
    date = "today"
    task = random.choise(RANDOM_TASKS)
    add_todo(date, task[2])
    text = "Task " + task + " added on date " + date
    bot.send_message(message.chat.id, text)

@bot.message_handler(commands=["show", "print"])
def show(message): # message.text = /print <date>
    command = message.text.split(maxsplit=1)
    date = command[1].lower()
    text = ""
    if date in tasks:
        text = date.upper() + "\n"
        for task in tasks[date]:
            text = text + "[]" + task + "\n"
    else:
        text = "No tasks for this date"
    bot.send_message(message.chat.id, text)

# Constantly accesses Telegram servers (long.polling - constant circulation).
# none_stop - will not stop if an error is received
bot.polling(none_stop=True)