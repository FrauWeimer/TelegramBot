import telebot

token = " "

bot = telebot.TeleBot(token)

@bot.message_handler(content_types=["text"])

def echo(message):
    bot.send_message(message.chat.id, message.text)

# Constantly accesses Telegram servers (long.polling - constant circulation).
# none_stop - will not stop if an error is received
bot.polling(none_stop=True)