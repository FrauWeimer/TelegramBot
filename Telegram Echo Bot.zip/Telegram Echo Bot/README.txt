Hello!

Today I sent you an example of a telegram echo bot. 

1. Find the @BotFather contact in Telegram.
2. Send him /newbot.
3. Choose the name of the bot.
4. Select the nickname of the bot (should end with Bot).
5. Copy the token.

To create bots for Telegram, various libraries are used that take on interaction with Telegram servers and other service functionality, 
leaving the user to write the logic for responding to messages.

There are many such libraries for Python, we will use telebot https://github.com/eternnoir/pyTelegramBotAPI

pip install pyTelegramBotAPI
import telebot

Line by line explanation of the code
#1 Import the library.
#3 We put the token we got earlier into a variable.
#5 Create a bot variable. It will be the key to the entire program. This is an object. Inside it there are already functions that we will call.
#7 Special syntax that specifies which messages the function defined next will process.
#8 Defining an echo function that takes one parameter, the message (to which we will respond).
#9 Function body. We send a message to the same chat from where we received it (message.chat.id) with the same text (message.text).